import cv2, os, numpy as np
from django.conf import settings
from .cnn_face_engine import preprocess, model

AUTH_IMG_DIR = settings.BASE_DIR / "surveillance/authorized/images"
AUTH_EMB_DIR = settings.BASE_DIR / "surveillance/authorized/embeddings"

AUTH_IMG_DIR.mkdir(parents=True, exist_ok=True)
AUTH_EMB_DIR.mkdir(parents=True, exist_ok=True)

def save_authorized_from_image(name, image_path):
    img = cv2.imread(image_path)
    emb = model.predict(preprocess(img))[0]

    np.save(AUTH_EMB_DIR / f"{name}.npy", emb)
    cv2.imwrite(str(AUTH_IMG_DIR / f"{name}.jpg"), img)


def save_authorized_from_video(name, video_path):
    cap = cv2.VideoCapture(video_path)
    embeddings = []

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        emb = model.predict(preprocess(frame))[0]
        embeddings.append(emb)

    avg_emb = np.mean(embeddings, axis=0)
    np.save(AUTH_EMB_DIR / f"{name}.npy", avg_emb)
