import numpy as np
from django.shortcuts import render
from .camera_manager import CameraManager
from .cnn_face_engine import preprocess, model, AUTH_DIR
from .system_state import SYSTEM_MODE
import surveillance.system_state as state

# Single shared camera
camera = CameraManager()


def dashboard(request):
    """
    Live monitoring dashboard
    """
    return render(request, "surveillance/dashboard.html")


import cv2
import numpy as np
from django.conf import settings
from django.shortcuts import render
from .camera_manager import CameraManager
from .cnn_face_engine import preprocess, model, is_face_already_registered
from .face_utils import extract_face

camera = CameraManager()

def register_authorized(request):
    request.session["mode"] = "REGISTER"
    msg = ""

    if request.method == "POST":
        name = request.POST.get("name", "").strip()

        if not name:
            msg = "Name is required"
            return render(request, "surveillance/register.html", {"msg": msg})

        img_dir = settings.MEDIA_ROOT / "authorized/images"
        emb_dir = settings.MEDIA_ROOT / "authorized/embeddings"
        img_dir.mkdir(parents=True, exist_ok=True)
        emb_dir.mkdir(parents=True, exist_ok=True)

        # 🚫 duplicate name
        if (emb_dir / f"{name}.npy").exists():
            request.session["register_status"] = "DUPLICATE"
            request.session["duplicate_name"] = name
            msg = f"Name '{name}' is already registered"
            return render(request, "surveillance/register.html", {"msg": msg})

        ret, frame = camera.read()
        if not ret or frame is None:
            msg = "Camera not ready"
            return render(request, "surveillance/register.html", {"msg": msg})

        face = extract_face(frame)
        if face is None:
            msg = "No face detected"
            return render(request, "surveillance/register.html", {"msg": msg})

        embedding = model.predict(preprocess(face))[0]

        # 🚫 duplicate face
        exists, existing_name = is_face_already_registered(embedding)
        if exists:
            request.session["register_status"] = "DUPLICATE"
            request.session["duplicate_name"] = existing_name
            msg = f"This face is already registered as '{existing_name}'"
            return render(request, "surveillance/register.html", {"msg": msg})

        # ✅ save
        cv2.imwrite(str(img_dir / f"{name}.jpg"), face)
        np.save(emb_dir / f"{name}.npy", embedding)

        request.session["register_status"] = "SUCCESS"
        request.session.pop("duplicate_name", None)
        request.session["mode"] = "MONITOR"

        msg = f"'{name}' registered successfully"

    return render(request, "surveillance/register.html", {"msg": msg})



from .models import IntrusionLog

from collections import defaultdict
from .models import IntrusionLog

from .models import IntrusionLog
from collections import OrderedDict

def intruder_gallery(request):
    intrusions = IntrusionLog.objects.filter(
        is_authorized=False,
        snapshot__isnull=False
    ).order_by("-timestamp")

    grouped = OrderedDict()

    for intr in intrusions:
        date_key = intr.timestamp.date().isoformat()  # string key
        if date_key not in grouped:
            grouped[date_key] = []
        grouped[date_key].append(intr)

    # convert to list for template safety
    grouped_list = [
        {"date": date, "items": items}
        for date, items in grouped.items()
    ]

    return render(
        request,
        "surveillance/intruders.html",
        {
            "groups": grouped_list,
            "total": intrusions.count(),
        }
    )

import os
import shutil
from django.conf import settings
from django.shortcuts import redirect
from .models import IntrusionLog


def delete_all_intruders(request):
    """
    Delete ALL intruder records and images
    """
    # Delete DB records
    IntrusionLog.objects.filter(is_authorized=False).delete()

    # Delete media folder
    intruder_dir = os.path.join(settings.MEDIA_ROOT, "intrusions")
    if os.path.exists(intruder_dir):
        shutil.rmtree(intruder_dir)
        os.makedirs(intruder_dir, exist_ok=True)

    return redirect("/intruders/")


def delete_intruders_by_date(request, date):
    """
    Delete intruders for a specific date (YYYY-MM-DD)
    """
    # Delete DB records
    IntrusionLog.objects.filter(
        is_authorized=False,
        timestamp__date=date
    ).delete()

    # Delete folder
    folder_path = os.path.join(
        settings.MEDIA_ROOT,
        "intrusions",
        date
    )
    if os.path.exists(folder_path):
        shutil.rmtree(folder_path)

    return redirect("/intruders/")

import os
from django.conf import settings

def authorized_users(request):
    img_dir = settings.MEDIA_ROOT / "authorized/images"
    users = []

    if img_dir.exists():
        for img in img_dir.iterdir():
            if img.suffix.lower() == ".jpg":
                users.append({
                    "name": img.stem,
                    "image": f"/media/authorized/images/{img.name}"
                })

    return render(
        request,
        "surveillance/authorized_users.html",
        {"users": users}
    )

from django.conf import settings
from django.shortcuts import redirect
import os

def delete_authorized_user(request, name):
    img = settings.MEDIA_ROOT / "authorized/images" / f"{name}.jpg"
    emb = settings.MEDIA_ROOT / "authorized/embeddings" / f"{name}.npy"

    if img.exists():
        img.unlink()

    if emb.exists():
        emb.unlink()

    return redirect("/authorized-users/")


from .models import AuthorizationLog

def authorization_logs(request):
    logs = AuthorizationLog.objects.all().order_by("-timestamp")

    name = request.GET.get("name")
    status = request.GET.get("status")
    date = request.GET.get("date")

    if name:
        logs = logs.filter(person_name__icontains=name)

    if status == "granted":
        logs = logs.filter(is_authorized=True)
    elif status == "denied":
        logs = logs.filter(is_authorized=False)

    if date:
        logs = logs.filter(timestamp__date=date)

    return render(
        request,
        "surveillance/auth_logs.html",
        {"logs": logs}
    )

from django.shortcuts import redirect
from .models import AuthorizationLog

def delete_auth_log(request, log_id):
    if request.method == "POST":
        AuthorizationLog.objects.filter(id=log_id).delete()
    return redirect("/auth-logs/")

def delete_all_auth_logs(request):
    if request.method == "POST":
        AuthorizationLog.objects.all().delete()
    return redirect("/auth-logs/")
