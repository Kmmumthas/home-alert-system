import cv2
import threading

class CameraManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                cls._instance = super().__new__(cls)
                cls._instance.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        return cls._instance

    def read(self):
        if not self.cap.isOpened():
            return False, None
        return self.cap.read()
