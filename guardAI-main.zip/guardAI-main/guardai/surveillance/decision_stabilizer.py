from collections import deque
import time

class DecisionStabilizer:
    def __init__(self, window=10, lock_time=3):
        self.decisions = deque(maxlen=window)
        self.last_decision = None
        self.lock_until = 0
        self.lock_time = lock_time

    def update(self, decision):
        now = time.time()

        # 🔒 if locked, keep previous decision
        if now < self.lock_until:
            return self.last_decision

        self.decisions.append(decision)

        # majority vote
        granted = self.decisions.count(True)
        denied = self.decisions.count(False)

        final = granted > denied

        # lock decision
        self.last_decision = final
        self.lock_until = now + self.lock_time

        return final
