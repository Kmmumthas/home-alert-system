import cv2
import time
import os
from datetime import datetime
from django.conf import settings
from .cnn_face_engine import recognize_live
from .models import IntrusionLog, AuthorizationLog
from .face_detector import detect_faces
from .face_buffer import FaceBuffer
from .cnn_face_engine import preprocess, model, recognize_embedding


detector = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

INTRUDER_COOLDOWN = 5
AUTH_LOG_COOLDOWN = 5

_last_intruder_time = 0
_last_auth_log_time = 0


def save_intruder(frame):
    now = datetime.now()
    date_folder = now.strftime("%Y-%m-%d")
    time_name = now.strftime("%H-%M-%S")

    save_dir = os.path.join(settings.MEDIA_ROOT, "intrusions", date_folder)
    os.makedirs(save_dir, exist_ok=True)

    filename = f"{time_name}.jpg"
    path = os.path.join(save_dir, filename)

    ok, buffer = cv2.imencode(".jpg", frame)
    if not ok:
        return

    with open(path, "wb") as f:
        f.write(buffer.tobytes())

    log = IntrusionLog(person_name="Unknown", is_authorized=False)
    log.snapshot.name = f"intrusions/{date_folder}/{filename}"
    log.save()


def process_live_frame(
    frame,
    mode="MONITOR",
    register_status=None,
    duplicate_name=None
):
    global _last_intruder_time, _last_auth_log_time

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        face = frame[y:y+h, x:x+w]
        if face.size == 0:
            continue

        ok, name = recognize_live(face)

        # ===== REGISTER MODE OVERLAY =====
        if mode == "REGISTER":
            if register_status == "DUPLICATE" and duplicate_name:
                color = (0, 165, 255)  # ORANGE
                label = f"ALREADY REGISTERED: {duplicate_name}"
            else:
                color = (255, 140, 0)  # BLUE
                label = "READY TO REGISTER"


        # ===== MONITOR MODE OVERLAY =====
        else:
            if ok:
                color = (0, 255, 0)
                label = f"GRANTED {name}"
            else:
                color = (0, 0, 255)
                label = "UNAUTHORIZED"

        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        cv2.putText(
            frame,
            label,
            (x, y-10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            color,
            2
        )

        now = time.time()

        if mode == "MONITOR" and ok:
            if now - _last_auth_log_time > AUTH_LOG_COOLDOWN:
                AuthorizationLog.objects.create(
                    person_name=name,
                    is_authorized=True
                )
                _last_auth_log_time = now

        if mode == "MONITOR" and not ok:
            if now - _last_intruder_time > INTRUDER_COOLDOWN:
                AuthorizationLog.objects.create(
                    person_name="Unknown",
                    is_authorized=False
                )
                save_intruder(frame)
                _last_intruder_time = now

    return frame
