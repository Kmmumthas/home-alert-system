# Global system state
SYSTEM_MODE = "MONITOR"  # or "REGISTER"
