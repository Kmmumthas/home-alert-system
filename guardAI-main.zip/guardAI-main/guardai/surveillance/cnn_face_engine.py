import cv2
import os
import numpy as np
from django.conf import settings
from .cnn_model import build_embedding_model
import numpy as np

model = build_embedding_model()

# ✅ SINGLE SOURCE OF TRUTH
AUTH_DIR = settings.MEDIA_ROOT / "authorized/embeddings"
AUTH_DIR.mkdir(parents=True, exist_ok=True)


def preprocess(face):
    face = cv2.resize(face, (160, 160))
    face = face.astype("float32") / 255.0
    return np.expand_dims(face, axis=0)


def recognize_live(face):
    """
    Returns:
    (True, name)  -> Authorized
    (False, "Unknown") -> Unauthorized
    """

    # 🔴 If no authorized users → everyone is unauthorized
    files = list(AUTH_DIR.glob("*.npy"))
    if not files:
        return False, "Unknown"

    emb = model.predict(preprocess(face))[0]

    best_dist = float("inf")
    best_name = "Unknown"

    for file in files:
        ref = np.load(file)
        dist = np.linalg.norm(ref - emb)

        if dist < best_dist:
            best_dist = dist
            best_name = file.stem

    # 🔐 Strict threshold
    if best_dist < 0.6:
        return True, best_name

    return False, "Unknown"

def is_face_already_registered(new_embedding, threshold=0.6):
    """
    Check if a face embedding already exists.
    Returns (True, name) if duplicate found.
    """
    files = list(AUTH_DIR.glob("*.npy"))
    if not files:
        return False, None

    for file in files:
        ref = np.load(file)
        dist = np.linalg.norm(ref - new_embedding)
        if dist < threshold:
            return True, file.stem

    return False, None

def recognize_embedding(embedding, threshold=0.65):
    files = list(AUTH_DIR.glob("*.npy"))
    if not files:
        return False, "Unknown"

    best_dist = float("inf")
    best_name = "Unknown"

    for file in files:
        ref = np.load(file)
        dist = np.linalg.norm(ref - embedding)

        if dist < best_dist:
            best_dist = dist
            best_name = file.stem

    if best_dist < threshold:
        return True, best_name

    return False, "Unknown"
