import cv2, os, numpy as np
from django.conf import settings
from .cnn_face_engine import preprocess, model

AUTH_EMB_DIR = settings.BASE_DIR / "surveillance/authorized/embeddings"

def load_authorized():
    data = {}
    for file in os.listdir(AUTH_EMB_DIR):
        name = file.replace(".npy", "")
        data[name] = np.load(AUTH_EMB_DIR / file)
    return data


def test_image(image_path):
    auth = load_authorized()
    img = cv2.imread(image_path)
    emb = model.predict(preprocess(img))[0]

    for name, ref in auth.items():
        if np.linalg.norm(ref - emb) < 0.8:
            return True, name
    return False, "Unknown"


def test_video(video_path):
    auth = load_authorized()
    cap = cv2.VideoCapture(video_path)

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        emb = model.predict(preprocess(frame))[0]
        for name, ref in auth.items():
            if np.linalg.norm(ref - emb) < 0.8:
                return True, name

    return False, "Unknown"
