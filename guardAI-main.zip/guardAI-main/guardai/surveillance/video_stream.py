import cv2
from django.http import StreamingHttpResponse
from .camera_manager import CameraManager
from .live_camera import process_live_frame

camera = CameraManager()

# 🔴 MONITOR STREAM (NO REGISTER STATE ALLOWED)
def gen_monitor(request):
    while True:
        ret, frame = camera.read()
        if not ret or frame is None:
            continue

        frame = process_live_frame(
            frame,
            mode="MONITOR"
        )

        ok, buffer = cv2.imencode(".jpg", frame)
        if not ok:
            continue

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n" +
            buffer.tobytes() +
            b"\r\n"
        )

def video_feed(request):
    return StreamingHttpResponse(
        gen_monitor(request),
        content_type="multipart/x-mixed-replace; boundary=frame"
    )


# 🔵 REGISTER STREAM (REGISTER ONLY)
def gen_register(request):
    while True:
        ret, frame = camera.read()
        if not ret or frame is None:
            continue

        frame = process_live_frame(
            frame,
            mode="REGISTER",
            register_status=request.session.get("register_status"),
            duplicate_name=request.session.get("duplicate_name")
        )

        ok, buffer = cv2.imencode(".jpg", frame)
        if not ok:
            continue

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n" +
            buffer.tobytes() +
            b"\r\n"
        )

def video_register(request):
    return StreamingHttpResponse(
        gen_register(request),
        content_type="multipart/x-mixed-replace; boundary=frame"
    )
