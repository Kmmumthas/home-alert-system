import numpy as np
from collections import deque

class FaceBuffer:
    def __init__(self, size=15):
        self.buffer = deque(maxlen=size)

    def add(self, embedding):
        self.buffer.append(embedding)

    def ready(self):
        return len(self.buffer) == self.buffer.maxlen

    def average(self):
        return np.mean(self.buffer, axis=0)

    def clear(self):
        self.buffer.clear()
