from django.db import models

class IntrusionLog(models.Model):
    person_name = models.CharField(max_length=100)
    is_authorized = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now_add=True)
    snapshot = models.ImageField(upload_to="intrusions/", null=True)

    def __str__(self):
        return self.person_name

class AuthorizationLog(models.Model):
    person_name = models.CharField(max_length=100)
    is_authorized = models.BooleanField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.person_name} | {'GRANTED' if self.is_authorized else 'DENIED'}"

