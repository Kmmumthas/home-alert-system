from django.db import models

class IntrusionEvent(models.Model):
    EVENT_TYPES = [
        ('LOGIN_FAIL', 'Login Failure'),
        ('BRUTE_FORCE', 'Brute Force'),
        ('HIGH_CPU', 'High CPU Usage'),
        ('SUSPICIOUS_IP', 'Suspicious IP'),
    ]

    event_type = models.CharField(max_length=50, choices=EVENT_TYPES)
    description = models.TextField()
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    severity = models.IntegerField(default=1)  # 1–5
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.event_type} - {self.severity}"
