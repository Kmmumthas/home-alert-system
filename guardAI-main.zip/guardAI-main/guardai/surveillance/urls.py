from django.urls import path
from .views import dashboard, register_authorized, intruder_gallery,authorization_logs, delete_all_intruders, delete_intruders_by_date, authorized_users, delete_authorized_user
from .video_stream import video_feed, video_register
from .views import delete_auth_log, delete_all_auth_logs

urlpatterns = [
    path("", dashboard, name="dashboard"),
    path("register/", register_authorized, name="register_authorized"),
    path("intruders/", intruder_gallery, name="intruder_gallery"),
    path("video/", video_feed, name="video_feed"),
       path("intruders/delete-all/", delete_all_intruders, name="delete_all_intruders"),
    path(
        "intruders/delete/<str:date>/",
        delete_intruders_by_date,
        name="delete_intruders_by_date"
    ),
    path("authorized-users/", authorized_users, name="authorized_users"),
path(
    "authorized-users/delete/<str:name>/",
    delete_authorized_user,
    name="delete_authorized_user"
),
path("auth-logs/", authorization_logs, name="authorization_logs"),
path("video-register/", video_register),
path("auth-logs/delete/<int:log_id>/", delete_auth_log),
path("auth-logs/delete-all/", delete_all_auth_logs),

]
