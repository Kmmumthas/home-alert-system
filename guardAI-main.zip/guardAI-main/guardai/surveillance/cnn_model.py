from tensorflow.keras import layers, models

def build_embedding_model():
    model = models.Sequential([
        layers.Conv2D(32, (3,3), activation='relu', input_shape=(160,160,3)),
        layers.MaxPooling2D(),
        layers.Conv2D(64, (3,3), activation='relu'),
        layers.MaxPooling2D(),
        layers.Conv2D(128, (3,3), activation='relu'),
        layers.Flatten(),
        layers.Dense(128)
    ])
    return model
