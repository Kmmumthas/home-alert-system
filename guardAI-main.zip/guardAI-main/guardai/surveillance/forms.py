from django import forms

class ImageUploadForm(forms.Form):
    name = forms.CharField(required=False)
    image = forms.ImageField(required=False)
    video = forms.FileField(required=False)
