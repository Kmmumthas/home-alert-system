import cv2
import mediapipe as mp

# ✅ SAFE access
mp_face = mp.solutions.face_detection

_detector = mp_face.FaceDetection(
    model_selection=1,          # side / distant faces
    min_detection_confidence=0.5
)

def detect_faces(frame):
    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    result = _detector.process(rgb)

    faces = []
    if result and result.detections:
        for det in result.detections:
            box = det.location_data.relative_bounding_box
            x = int(box.xmin * w)
            y = int(box.ymin * h)
            bw = int(box.width * w)
            bh = int(box.height * h)
            faces.append((x, y, bw, bh))

    return faces
